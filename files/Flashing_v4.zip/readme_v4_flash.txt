﻿2021-02-02

Прошиваем cc2652 c помощью питоновского прошивальщика.
Проверено на Windows 7 x64 + python 3.8.6 на моих стиках (https://github.com/egony).
На линуксе все аналогично.

------------------------------------

Внимание!
Данный способ работает, только если в чипе есть прошивка с поддержкой BSL!

Внимание!
Залив прошивку не от того устройства, или прошивку без BSL, или прошивку, в которой BSL 
активируется НЕ через DIO_15 - есть шанс получить кирпич, кторый можно поднять только программатором!
Если качаете прошивку от KoenKK, сверьтесь с типом своего стика в табличке:
https://github.com/Koenkk/Z-Stack-firmware/tree/master/coordinator/Z-Stack_3.x.0/bin

------------------------------------

Качаем и распаковываем прошивальщик: https://github.com/JelmerT/cc2538-bsl
Качаем и устанавливаем python 3.8.6: http://www.python.org/download

Устанавливаем необходимые дополнения:
pip3 install pyserial
pip3 install intelhex


Процесс прошивки для стиков разных ревизий выглядит по-разному из-за разных методов активации бутлоадера. 
Обычно это делается кнопками, но уже есть стики, в которых бутлоадер активируется самим прошивальщиком.

Внимание!!! Все нижесказанное справедливо ТОЛЬКО для стиков, которые собирал я лично.

1. Активация бутлоадера кнопками (не для стиков из п.2 и п.3).
Зажать кнопки RESET (RST) и FLASH (BSL), отпускаете RESET, затем отпускаете FLASH.
Командная строка:
python.exe cc2538-bsl.py -p COM3 -e -w -v znp_CC2652P_E72_sdk_4_20_01_04_20200921.hex

2. Активация прошивальщиком (стики rev.2.1E)
Нажатие кнопок не требуется.
Командная строка:
python.exe cc2538-bsl.py -p COM3 --bootloader-invert-lines -e -w -v znp_CC2652P_E72_sdk_4_20_01_04_20200921.hex

3. Активация прошивальщиком (стики rev.2.0E и rev.1.0R)
Внимание!!! Для прошивки следует использовать модифицированный файл cc2538-bsl_egony.py
Нажатие кнопок не требуется.
Командная строка:
python.exe cc2538-bsl_egony.py -p COM3 --bootloader-invert-lines -e -w -v znp_CC2652P_E72_sdk_4_20_01_04_20200921.hex


Процесс выглядит примерно так:

------------------------------------
C:\Misc\cc2538-bsl>flash_2652.cmd
Opening port COM3, baud 500000
Reading data from CC1352P2_CC2652P_other_20201113.hex
Your firmware looks like an Intel Hex file
Connecting to target...
CC1350 PG2.0 (7x7mm): 352KB Flash, 20KB SRAM, CCFG.BL_CONFIG at 0x00057FD8
Primary IEEE Address: 00:12:4B:00:21:B4:94:C2
    Performing mass erase
Erasing all main bank flash sectors
    Erase done
Writing 360448 bytes starting at address 0x00000000
Write 104 bytes at 0x00057F980
    Write done
Verifying by comparing CRC32 calculations.
    Verified (match: 0x55e2e461)
------------------------------------

По окончании прошивки, возможно, потребуется переткнуть стик в USB или нажать RESET. 
Обычно этого не нужно делать.

